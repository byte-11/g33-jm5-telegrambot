package uz.pdp.bot;

public class BotConfig {
    public static final String BOT_USERNAME = "@alpha_0110_bot";
    public static final String BOT_TOKEN = "6965653871:AAGgTFPR9UDSzSi0o2_HmuRhVeG0BSYP_Qw";
}
